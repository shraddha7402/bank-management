-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 15, 2019 at 08:55 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bank`
--

-- --------------------------------------------------------

--
-- Table structure for table `baccounts`
--

CREATE TABLE `baccounts` (
  `Acc_Id` int(10) NOT NULL,
  `Acc_Name` varchar(30) NOT NULL,
  `PhoneNumber` bigint(10) NOT NULL,
  `Address` varchar(20) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `AdharNumber` int(10) NOT NULL,
  `Balance` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `baccounts`
--

INSERT INTO `baccounts` (`Acc_Id`, `Acc_Name`, `PhoneNumber`, `Address`, `Email`, `AdharNumber`, `Balance`) VALUES
(1001, 'Shraddha Pradeshi', 9545373275, 'dhule', 'pardeshiShraddha519@gmail.com', 954521123, 16800),
(1002, 'lina prashant gharate', 1346972322, 'nana krushan colony', 'linagharate2002@gmail.com', 46841321, 3000),
(1003, 'Nivedita bapu mail', 3628252268, 'Old Dhule', 'Nivimail2002@gmail.com', 3344231, 40000),
(2001, 'Aarnav Ahuja', 9423228252, 'Delhi', 'AhujaAarnav1972@gmail.com', 123654987, 499800),
(5012, 'praju badgujar', 1546131260, 'GTP stop,Dhule', 'praju8201@gmail.com', 454358744, 9000);

-- --------------------------------------------------------

--
-- Table structure for table `bemployees`
--

CREATE TABLE `bemployees` (
  `Emp_Id` int(10) NOT NULL,
  `Emp_name` varchar(30) NOT NULL,
  `Phone` bigint(10) NOT NULL,
  `Address` varchar(20) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Job` varchar(10) NOT NULL,
  `Salary` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bemployees`
--

INSERT INTO `bemployees` (`Emp_Id`, `Emp_name`, `Phone`, `Address`, `Email`, `Job`, `Salary`) VALUES
(1001, 'Shraddha  hajari', 1954537327, 'Bangalore', 'hajarishraddha519@gmail.com', 'manager', 425613),
(2002, 'Vivan Patil', 2145361528, 'pune', 'VivaanPatil@gmail.com', 'manager', 425613),
(2003, 'Reyansh Rajput', 1295453775, 'mumbai', 'ReyanshRajput50@gmail.com', 'Bank Telle', 215533),
(2023, 'Rahul patil', 1136819869, 'Nashik', 'Rahulpatil**@gmail.com', 'clerk', 120235),
(2130, 'Rohit Rane', 1297638540, 'Nagpur', 'RohitRane25@gmail.com', 'Gaurd', 50345),
(5412, 'Aarnav Kathri', 942322825, 'Goa', 'KathriAarnav232@gmail.com', 'Clerk', 412342),
(5421, 'Reyansh Agrawal', 1225135466, 'Thane,mumbai', 'ReyanshAgrawal2000@gmail.com', '542135', 0),
(6100, 'Pratik PM', 855107620, 'pune', 'MPMMali1402@gmail.com', 'Manager', 612453),
(6213, 'Vihaan mali', 1325163144, 'chennai', 'maliVihaan23@gmail.com', 'Loan Offic', 600452);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `baccounts`
--
ALTER TABLE `baccounts`
  ADD PRIMARY KEY (`Acc_Id`);
ALTER TABLE `baccounts` ADD FULLTEXT KEY `Email` (`Email`);

--
-- Indexes for table `bemployees`
--
ALTER TABLE `bemployees`
  ADD PRIMARY KEY (`Emp_Id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
